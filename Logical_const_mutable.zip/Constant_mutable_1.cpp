// Constant_mutable_1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
/*
 * You have a constant object, but for debugging purposes want to track how often a constant method is called on it.
 * Logically you're not changing the object.
 * Note that if you're making decisions in your program based on a mutable variable, you've almost certainly violated
 * logical const-ness and need to rethink things.
 */

#include <iostream>
#include "Employee.h"
int main()
{
    my_lib::Employee e1("Sayali"); /*Non-constant object*/
    std::cout << "Original Name : " <<  e1.getName() << std::endl;
    e1.setName("Sayaji");
    std::cout << "Updated Name : " << e1.getName() << std::endl;
    std::cout << "e1 Access count : " << e1.getAccessCount() << std::endl;

    const my_lib::Employee e2("Aparajita"); /*constant object*/
    std::cout << "Original Name : " << e2.getName() << std::endl;
   // e2.setName("Appu"); 
    std::cout << "Updated Name : " << e2.getName() << std::endl;
    std::cout << "e2 Access count : " << e2.getAccessCount() << std::endl;
}

