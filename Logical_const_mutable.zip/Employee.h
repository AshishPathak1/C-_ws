#pragma once
#include <string>
namespace my_lib {

	class Employee
	{
	public:
		Employee() = delete;

		Employee(std::string _name);
		virtual ~Employee()= default;
				
		void setName(std::string _name);

		/*constant method*/
		std::string getName() const; /*returns the name of the employee*/
		size_t getAccessCount() const;/*returns the count of number of times the object has been accessed*/
	private:
		std::string name;
		mutable size_t access_count{0};
	};

}