#include "Employee.h"

namespace my_lib {
	Employee::Employee(std::string _name) :name{ _name }
	{}

	std::string Employee::getName() const
	{
		access_count++;
		return name;
	}

	void Employee::setName(std::string _name)
	{
		access_count++;
		name = _name;
	}

	size_t Employee::getAccessCount() const
	{
		return access_count;
	}
}