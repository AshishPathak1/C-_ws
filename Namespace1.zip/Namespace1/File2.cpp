#include<iostream>

int gvar2{ 60 }; //file scope with external linkage

namespace { //identifiers will have file scope with internal linkage
	int gvar1{ 40 };
	void doit() {
		std::cout << "Doing it!\n";
	}
}

//Function Definition

void printit() { //file scope with external linkage

	std::cout << "In other file gvar1 : " << gvar1 << std::endl;
	std::cout << "In other file gvar2 : " << gvar2 << std::endl;
	doit();
}



