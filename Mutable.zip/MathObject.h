#pragma once
namespace mylib {
    class MathObject {
    public:

        MathObject() : pi_cached(false), piVal(0) {
        }

        double pi() const {
            if (!pi_cached) {
                /* This is an insanely slow way to calculate pi. */
                piVal = 4;
                for (long step = 3; step < 1000000000; step += 4) {
                    piVal += ((-4.0 / (double)step) + (4.0 / ((double)step + 2)));
                }
                pi_cached = true;
            }
            return piVal;
        }
    private:
        mutable bool pi_cached;
        mutable double piVal;
    };
}