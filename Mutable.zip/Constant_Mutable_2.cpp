// Constant_Mutable_2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "MathObject.h"
int main()
{
    const mylib::MathObject mobj1;
    std::cout << "PI = " << mobj1.pi() << std::endl;
    std::cout << "PI = " << mobj1.pi() << std::endl;
    std::cout << "PI = " << mobj1.pi() << std::endl;
    return 0;
}
