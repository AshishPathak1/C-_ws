// Inheritance_11.cpp : 
// Understand Abstract Base class

#include <iostream>
#include "Car.h"
#include "MarutiCar.h"
#include "Micra.h"
#include <string>
using namespace std::literals;

void use_car(mylib::Car & mycar) {
    std::cout << "Using : " << mycar.get_model() << '\n';
    mycar.start_engine();
    mycar.accelerate();
    mycar.apply_brake();
    std::cout << "\n";
}

int main()
{

	{
		mylib::MarutiCar my_maruti("WagonR"s, "MH-14AE9707"s, 110);

        //Early or static binding; when object is used to invoke a method
        my_maruti.start_engine();
        my_maruti.accelerate();
        my_maruti.apply_brake();

		/* Pointers and Reference of abstract class type "mylib::Car" can be created*/
		mylib::Car* car_pointer{ &my_maruti };
        car_pointer->start_engine();
       
        mylib::Car& car_ref1{ my_maruti }; //reference requires initializers
        car_ref1.start_engine();

		/*Cannot creeate instance of Abstract class
		 Object of abstract class type "mylib::Car" is not allowed*/
	 /*    mylib::Car mycar("Padmani"s,"MH-14LM9747"s,100);
         car_pointer = &mycar;
         car_pointer->start_engine();
         
         mylib::Car& car_ref2{ mycar};
         car_ref2.start_engine();*/
	}
    //{
    //    /*
    //    * When objects are used to invoke a method it always performs static (early) binding
    //    */
    //    mylib::MarutiCar my_maruti("WagonR", "MH-14AE9707", 110);
    //    my_maruti.start_engine();
    //    my_maruti.accelerate();
    //    my_maruti.apply_brake();
    //}

    {
        
        mylib::Car* car_ptr{}; //Pointer of Abstract super class
        mylib::MarutiCar my_maruti("WagonR", "MH-14AE9707", 110); //Object of subclass
        car_ptr = &my_maruti;
        /*Dynamic (Late) binding;
        since the start_engine() method has been defiend virtual in the superclass;
        it is not the type of the pointer but the type of the object to which the 
        pointer is pointing to will decide which method is to be called*/
        car_ptr->start_engine();

        /*Static (Early)  Binding; 
        since the next two methods are not decalred virtual in Car class;
        it is the type of the pointer that will decide which method is to be called*/
        car_ptr->accelerate();
        car_ptr->apply_brake();

        //using reference
        mylib::Car& car_ref{ my_maruti };
        /*Dynamic (Late) binding*/
        car_ref.start_engine();
        /*Static (Early)  Binding*/
        car_ref.accelerate();
        car_ref.apply_brake();
    }

    {
        mylib::MarutiCar my_maruti("WagonR", "MH-14AE9707", 110);
        mylib::MicraCar my_micra("Micra", "MH-14XE8989", 100);
        use_car(my_maruti);
        use_car(my_micra);

    }
}
