#pragma once
#include "Car.h"
namespace mylib {
	class MarutiCar : public Car
	{
	public:
		MarutiCar(std::string _model, std::string _reg_number, int _top_speed);
		void start_engine() override;
	};
}

