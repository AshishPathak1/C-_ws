#include <iostream>
#include "MarutiCar.h"


mylib::MarutiCar::MarutiCar(std::string _model, std::string _reg_number, int _top_speed)
	: mylib::Car(_model, _reg_number, _top_speed)
{
}

void mylib::MarutiCar::start_engine()
{
	std::cout << "Insert the Key in Ignition Key hole\n";
	std::cout << "Hold cluth\n";
	std::cout << "Turn the key clock wise till the car engine starts\n";
}
