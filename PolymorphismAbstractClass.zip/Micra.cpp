#include "Micra.h"
#include <iostream>



mylib::MicraCar::MicraCar(std::string _model, std::string _reg_number, int _top_speed)
	: mylib::Car(_model, _reg_number, _top_speed)
{
}

void mylib::MicraCar::start_engine()
{
	std::cout << "Hold cluth\n";
	std::cout << "Press the start button\n";

}
