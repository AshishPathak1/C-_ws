#include <iostream>
#include <stdexcept>
#include "Doctor.h"
#include <string>
using namespace std::literals;

void mylib::Doctor::update_specialization(std::string new_specialization)
{
    if (new_specialization.empty()) {
        throw std::invalid_argument("Specialization cannot be empty string\n");
    }
    specialization = new_specialization;
}

mylib::Doctor::Doctor(std::string name, std::string new_specialization):Person(name)
{
    std::cout << "Doctor created\n";
    update_specialization(new_specialization);
}

mylib::Doctor::~Doctor()
{
    std::cout << "Doctor destroyed\n";
}

std::string mylib::Doctor::get_specialization() const
{
    return specialization;
}

void mylib::Doctor::set_specialization(std::string new_specialization)
{
    update_specialization(new_specialization);
}

std::string mylib::Doctor::operate()
{
    return "Operating the patient"s;
}

 std::string mylib::Doctor::get_name() const
{
    return "Dr. "s + Person::get_name();
}

 void mylib::Doctor::whoami()
 {
     std::cout << Person::get_name() << " is Doctor\n";
 }
