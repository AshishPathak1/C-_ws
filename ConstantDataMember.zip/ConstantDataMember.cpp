// ConstantDataMember.cpp : 
// Constant Data Member
#include <iostream>
#include "Point.h"
#include "Person.h"
using namespace std::string_literals;

void static_const_demo() {
    std::cout << "Origin for X-Y plane : x:" << mylib::Point::x_origin << ",y:"
        << mylib::Point::y_origin << '\n';
    mylib::Point p1(12, 45);
    std::cout << "Point [" << p1.getX() << ", " << p1.getY() << "]\n";
    mylib::Point p2(11, 44);
    std::cout << "Point [" << p2.getX() << ", " << p2.getY() << "]\n";
    std::cout << "Origin for X-Y plane : x:" << p2.x_origin << ",y:" << p2.y_origin << '\n';
}

void constant_instance_data() {
    mylib::Person p1("Kailash"s,"O+"s, 2000);
    p1.print_details();
   
    mylib::Person p2("Kavita"s,"B-", 2005);
    p2.print_details();

    mylib::Person p3("Kumar"s, 2005);
    p3.print_details();
}


int main()
{
    //static_const_demo();
    constant_instance_data();
}
