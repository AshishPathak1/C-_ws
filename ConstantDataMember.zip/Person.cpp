#include <iostream>
#include "Person.h"

/*Member initialization list is used to initialize the constant data member*/
mylib::Person::Person(std::string tname, std::string bg, int tyear):year_of_birth(tyear),blood_group(bg)
{
	name = tname;
	/*Ctor body cannot be used to initialize the constant data member*/
	//year_of_birth = tyear;
}

/*Member initialization of constant member has happend in the class declaration*/
mylib::Person::Person(std::string tname, int tyear) :year_of_birth(tyear)
{
	name = tname;
}

void mylib::Person::print_details() const
{
	std::cout << "Name : " << name 
		<<  "\tBlood group : " << blood_group
		<< 	"\tYear of birth : " << year_of_birth << '\n';
}

const std::string& mylib::Person::getName() const
{
	return name;
}

void mylib::Person::setName(std::string& newname)
{
	name = newname;
}

int mylib::Person::getYearOfBirth() const
{
	return year_of_birth;
}

std::string mylib::Person::getBloodGroup() const
{
	return blood_group;
}
