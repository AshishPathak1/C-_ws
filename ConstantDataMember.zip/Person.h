#pragma once
#include <string>
#include <ctime>

namespace mylib {
	class Person
	{
	private:
		const int year_of_birth;
		std::string name;
		const std::string blood_group{ "AB+" };
		//const int x;
	public:
		Person(std::string name,std::string bg, int year);
		Person(std::string name,  int year);
		void print_details() const;
		const std::string& getName()const;
		int getYearOfBirth() const;
		std::string getBloodGroup()const;

		void setName(std::string& newname);
	};

}
