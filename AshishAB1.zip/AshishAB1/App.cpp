	// AshishAB.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>
#include "vector"
#include "AddressBookEntry.h"
#include <algorithm>
#include <string>

using namespace std::literals;

void printAddressBookEntry(const AddressBookEntry& entry) {
    std::cout << "Name: " << entry.getName() << std::endl;
    std::cout << "Address: " << entry.getAddress() << std::endl;
    std::cout << "Phone Number: " << entry.getPhoneNumber() << std::endl;
    std::cout << std::endl;
}

void printAddressBook(const std::vector<AddressBookEntry>& addressBook) {
    for (auto& entry : addressBook) {
        printAddressBookEntry(entry);
        std::cout << std::endl;
    }
}

// Function to add an entry to the address book
void addEntry(std::vector<AddressBookEntry>& addressBook, const AddressBookEntry& entry) {
    addressBook.push_back(entry);  
    std::cout << "Entry added successfully." << std::endl;
}

char toupper_case(char ch) {
    return std::toupper(ch);
}

bool compareStrings(const std::string& s1, const std::string& s2)
{
    std::string s1_t{ s1 };
    std::transform(s1_t.cbegin(), s1_t.cend(), s1_t.begin(), toupper_case);
    std::string s2_t{ s2 };
    std::transform(s2_t.cbegin(), s2_t.cend(), s2_t.begin(), toupper_case);
    return s1_t == s2_t;
}

// Function to delete an entry from the address book
void deleteEntry(std::vector<AddressBookEntry>& addressBook, const std::string& name) {
    bool found = false;
    for (auto it = addressBook.begin(); it != addressBook.end();) {
        if (compareStrings(it->getName(),name)) {
            it = addressBook.erase(it);
            found = true;
            break;
        }
        ++it;
    }
    if (found)
        std::cout << "Entry deleted successfully." << std::endl;
    else
        std::cerr << "Entry not found." << std::endl;
}



// Function to search for an entry in the address book
void searchEntry( std::vector<AddressBookEntry>& addressBook, const std::string& name) {
    bool found = false;
    for (const auto& entry : addressBook) {
        if (compareStrings(entry.getName(),name)) { //case sensitive
            found = true;
            std::cout << "Entry found:" << std::endl;
            printAddressBookEntry(entry);
            break;
        }
    }
    if (!found) {
        std::cerr << "Entry not found." << std::endl;
    }
}

int main()
{
    std::vector<AddressBookEntry> addressBook;

    // Usage examples:
    // Add entries
    AddressBookEntry contact1("John Doe"s, "123 Main St"s, 1234567890);
    addEntry(addressBook, contact1);

    AddressBookEntry contact2("John Mcarthy"s, "122 Main St"s, 1254567890);
    addEntry(addressBook, contact2);
    
    AddressBookEntry contact3("John Mac"s, "124 Main St"s, 1234567590);
    addEntry(addressBook, contact3);

    //PrintAddressBook
    printAddressBook(addressBook);

    // Search entry
    searchEntry(addressBook, "JOHN Doe"s);

    // Delete entry
    deleteEntry(addressBook, "JOHN Doe"s);

    printAddressBook(addressBook);
    return 0;
}
