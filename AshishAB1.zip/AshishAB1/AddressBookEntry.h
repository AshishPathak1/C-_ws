#pragma once
#pragma once
#include <string>
#include <string_view>
using namespace std::literals;
class AddressBookEntry {
private:
    std::string name;
    std::string address;
    std::string phoneNumber;

    bool isPhoneNumberValid(const std::string&& newphoneNumber);
    // Check if the phone number consists of only digits
    bool isNameOrAddressValid(const std::string&);
   
public:
    // Constructor
    AddressBookEntry() :AddressBookEntry("Name not set"s, "Address not set"s) {};
    explicit AddressBookEntry(const std::string& newName, const std::string& newAddress = "Address not set"s, unsigned long long newphoneNumber = 0);

    // Getters
    std::string getName() const;
    std::string getAddress() const;
    unsigned long long getPhoneNumber() const;

    // Setters
    void setName(const std::string& newName);
    void setAddress(const std::string& newAddress);
    void setPhoneNumber(const unsigned long long  newPhoneNumber);
};;
