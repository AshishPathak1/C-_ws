#include "AddressBookEntry.h"
#include <iostream>
#include <algorithm>
#include <string_view>
// AddressBook implementation
AddressBookEntry::AddressBookEntry(const std::string& newName, const std::string& newAddress, unsigned long long newphoneNumber) {
    name = newName;
    address = newAddress;
    if (isPhoneNumberValid(std::to_string(newphoneNumber))) {
        phoneNumber = std::to_string(newphoneNumber);
    }
    else {
        std::cerr << "Valid phone number is 10 digits long!. Looks like this contact doesn't have phone number\n"
            << std::endl;
        phoneNumber = "0"; // Assign an empty string as default value for phoneNumber
    }
}
std::string AddressBookEntry::getName() const {
    return name;
}

std::string AddressBookEntry::getAddress() const {
    return address;
}

unsigned long long AddressBookEntry::getPhoneNumber() const {
    return std::stoull(phoneNumber);
}

void AddressBookEntry::setName(const std::string& newName) {
    if (isNameOrAddressValid(newName)) {
        this->name = newName;
    }
    else {
        std::cerr << "Name not set!\n\n";
    }
}

void AddressBookEntry::setAddress(const std::string& newAddress) {
    if (isNameOrAddressValid(newAddress)) {
        this->address = newAddress;
    }
    else {
        std::cerr << "Address not set!\n\n";
    }

}

bool AddressBookEntry::isPhoneNumberValid(const std::string&& new_phone_number) {
    // Check if the phone number consists of only digits
    for (char c : new_phone_number) {
        if (not isdigit(c)) {
            return false;
        }
    }

    constexpr size_t expected_number_of_digits{ 10 };
    // Check if the size of the phone number is 10
    return new_phone_number.size() == expected_number_of_digits;
}

bool AddressBookEntry::isNameOrAddressValid(const std::string& data)
{
    auto count = std::count_if(data.begin(), data.end(), [](unsigned char i) { return std::isalnum(i); });
    return count != 0;
}



void AddressBookEntry::setPhoneNumber(const unsigned long long  newPhoneNumber) {
    if (isPhoneNumberValid(std::to_string(newPhoneNumber))) {
        this->phoneNumber = std::to_string(newPhoneNumber);
    }
    else {
        std::cerr << "Phone number is not valid." << std::endl;
        this->phoneNumber = "0";
    }
}