// Namesspace8.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "my_library.h"

int main()
{

    
    //case - I : Need the old implementation
    {
        my_library::v1::doit();
    }
    //case - II : Need the new Implementation
    {
        my_library::v2::doit();
    }

    //case - III : Need the Lasted Implementation
    {
        my_library::doit();
     
    }
}

