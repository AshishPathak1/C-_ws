#include <iostream>

namespace myspace {

	void doit() {
		std::cout << "Doing it other way\n";
	}
}