// 52.Namespace_1.cpp : 
// Basics

#include <iostream>
#include <cmath>
#include <numbers>



/*
Brings all the names from the std namespace into the current scope
*/
//using namespace std;

/* only the 4 names listed below are brough in the current scope*/
using std::endl;
using std::cout;
using std::cerr;

namespace myspace {
    extern void doit();
}


namespace myspace {
    double cos(double deg) {

        double result = std::cos(deg*(std::numbers::pi/180));
        return result;
    }
  
}

namespace yourspace {
    void doit() {
        std::cout << "Doing it your way\n";
    }
}
void basics() {
    cout << "Hello World! " << endl;
    cerr << "Error message " << endl;
    /*Hides the names cout, endl , cerr from the standard lib */
    float cout{ 5.6F };
    int cerr{ 10 };
    char endl{ '\n' };
    cerr = cout + cout;
 /*   cout << "Hello World! " << endl;
    cerr << "Error message " << endl;*/

    std::cin >> endl;
}

void  resolving_conflicts() {
    cout << "Cosine of 90 : " << myspace::cos(90) << '\n';
    myspace::doit();
    yourspace::doit();
}
 
int main()
{
   // basics();
    resolving_conflicts();

}
