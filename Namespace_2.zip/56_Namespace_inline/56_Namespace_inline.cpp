// 56_Namespace_inline.cpp : 
// Inline namespace

#include <iostream>

namespace foo {
    void foo_func() {
        std::cout << "Executing foo::foo_func\n";
    }
}

/*All the names from foo namespace have been brought in the global namespace explicitly */
using namespace foo;

//inline namespace allowed since C++20
inline namespace bar {
    void bar_func() {
        std::cout << "Executing bar::bar_func()\n";
    }
}

namespace outerspace {
    void outer_func() {
        std::cout << "Executing outerspace::outer_func()\n";
    }
    namespace first_inner {
        void first_func() {
            std::cout << "Executing outerspace::first_inner::first_func()\n";
        }
    }

    inline namespace second_inner {
        void second_funct() {
            std::cout << "Executing outerspace::second_inner::second_func()\n";
        }
    }
}

int main()
{
    foo::foo_func();
    foo_func(); // Brought in the global namespace by using "using" statement

    bar::bar_func();
    bar_func();

    outerspace::outer_func();
    outerspace::first_inner::first_func();
  //  outerspace::first_func();

    outerspace::second_inner::second_funct();
    outerspace::second_funct();
 //   second_funct();
}
