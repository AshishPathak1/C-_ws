
/*Implementation of vector.h */
#include <iostream>
#include "vector.h"

void vector::draw_vector_image(Image img)
{
	std::cout << "Drawing vector image\n";
}

void vector::delete_vector_image() {
	std::cout << "Deleted Vecctor image\n";
}
