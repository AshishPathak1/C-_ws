
#include <iostream>
#include "Geometry.h"

void Geometry::draw()
{
	std::cout << "Drawing Geometry\n";
}

vector::vector()
{
	std::cout << "Initializing Vector\n";
}

void vector::doit()
{
	std::cout << "doing Vector\n";
}
