// 55_Namespace_library.cpp : 
// How to design library ?

/*User of library*/

#include <iostream>
//#include "vector"
//#include "Geometry.h"
#include "vector.h"

#include "GeometryBox.h"
#include "PackagingBox.h"

void  incorrect_design() {
    Image img;
    vector v;
    v.draw_vector_image(img);
    v.delete_vector_image();
  //  v.doit();
}


void  correct_design() {
    geometry::Box b1;
    b1.use_box();

    package::Box b2;
    b2.use_box();
}

int main()
{
    incorrect_design();
    correct_design();
   
    return EXIT_SUCCESS;
}
