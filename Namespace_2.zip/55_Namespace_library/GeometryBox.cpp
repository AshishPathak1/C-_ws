#include <iostream>
#include "GeometryBox.h"

geometry::Box::Box()
{
	std::cout << "creating Geometry box\n";
}

void geometry::Box::use_box()
{
	std::cout << "Using Geometry box\n";
}
