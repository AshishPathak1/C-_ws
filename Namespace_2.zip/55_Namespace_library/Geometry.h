#pragma once

class vector {
public:
	vector();
	void doit();
};

class Geometry
{
	vector v;
public:
	void draw();
};

