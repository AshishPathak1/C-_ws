#pragma once

namespace geometry {
	class Box;
	
}

class geometry::Box {
public:
	Box();
	void use_box();
};