#include <iostream>
#include "PackagingBox.h"

package::Box::Box() {
	std::cout << "Creating Packaging box\n";
}

void package::Box::use_box() {
	std::cout << "Using Packaging Box\n";
}