#pragma once
/*Contract/Promise made by supplier*/
class Image {

};

class vector
{
public:
	void draw_vector_image(Image img);
	void delete_vector_image();
};

