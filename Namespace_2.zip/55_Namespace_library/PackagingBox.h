#pragma once

namespace package {
	class Box
	{
	public:
		Box();
		void use_box();
	};
}
