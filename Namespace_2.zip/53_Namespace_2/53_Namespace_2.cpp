// 53_Namespace_2.cpp : Anonymous namespace

#include <iostream>

extern float fdata;
extern void doit();

namespace first {
    extern void first_function();
    extern int first_data;
    void second_function() {
        std::cout << "Calling first function from second function\n";
        first_function();
    }
}

namespace {
    extern void anonymous();
    extern int a_data;
    void my_fun() {
        std::cout << "Having fun\n";
    }
    double cout = 5.6;
}


int main()
{
    std::cout << "In main function\n";
    doit();
    std::cout << "fdata from file_one.cpp " << fdata << '\n';
    /**/
    first::first_function();
    first::second_function();
    std::cout << "first data : " << first::first_data << '\n';
    /*Identifers from the anonymous namespace can be referred directly within its own file*/
    my_fun();
    std::cout << cout << '\n';
  //  anonymous();
  //  std::cout << a_data << '\n';
} 
