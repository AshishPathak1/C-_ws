#include <iostream>

float fdata = 4.65F;

void doit() {
	std::cout << "Fileone.cpp::doit\n";
}

/*Named namespace is open
 Linkage is external i.e. identifiers can be accessed in other files by declaring using extern
*/
namespace first {
	void first_function() {
		std::cout << "first function from namespace first\n";
	}
	int first_data = 100;
}

/*Unnamed namespace is closed
 Linkage of the identifiers in internal ie local to this file only
*/
namespace  {
	void anonymous() {
		std::cout << "anonymous from file_one.cpp\n";
	}
	int a_data = 900;
}