// 54_namespace_3.cpp : 
// Namespace separated within the same file
// Namespace split over multiple files 
// The name of a global namespace must be unique among the global names in a program. 
// nested namespace
#include <iostream>
#include <string>

namespace math_operations {
    extern double my_sqrt(float);
    double my_sqrt(int val) {
        std::cout << "Calculating Square root of integer\n";
        return 0.0;
    }

}

namespace other {
    void other() {
        std::cout << "Calling function other from other namespace\n";
    }
}
//The name of a global namespace must be unique among the global names in a program. 
//int other = 77;

//Namespace separated within the same file
namespace math_operations {
      double my_sqrt(double val) {
        std::cout << "Calculating Square root of double\n";
        return 0.0;
    }

}

//nested namesapce
namespace math_operations {
    namespace handle_long {
        const long MAX_LONG = 500000000L;
        void f1(void);
        void f2(void);

    }
    /*Function declared inside the namespace handle_lon is defined at intermediate level*/
    void handle_long::f1(void) {

    }
}

/*Function declared inside the namespace is defined globally*/
void math_operations::handle_long::f2(void) {

}

int main()
{
    math_operations::my_sqrt(40);
    math_operations::my_sqrt(40.1F);
    math_operations::my_sqrt(40.1);
    other::other();

    using namespace other;
    // other(); //	'other': ambiguous symbol	

    /*refering the namespace members*/
    //std::cout << "MAX_LONG : " << math_operations::handle_long::MAX_LONG << '\n'; // fully qualified
    //
    //using namespace math_operations; /* bring all the names from math_operations in the current scope*/
    //std::cout << "MAX_LONG : " << handle_long::MAX_LONG << '\n'; 
    //my_sqrt(40);
    //my_sqrt(40.1F);
    //my_sqrt(40.1);
    //     using namespace handle_long;
    //    //using namespace math_operations::handle_long;
    //    std::cout << "MAX_LONG : " << MAX_LONG << '\n';

    //Shorthand : namespace alias

    namespace math_op = math_operations;
    std::cout << "MAX_LONG : " << math_op::handle_long::MAX_LONG << '\n';
    namespace mo_hl = math_op::handle_long;
    std::cout << "MAX_LONG : " << mo_hl::MAX_LONG << '\n';


    // Namespace declarations are context sensitive
    //string s1; // Error
    std::string s2;
    {
        using namespace std;
        string s3 = "Hello\n";
        cout << s3 << endl;
    }

    //string s4; error
}