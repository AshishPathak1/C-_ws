
#include <iostream>

//Namespace split over multiple files
namespace math_operations {
    double my_sqrt(float val) {
        std::cout << "Calculating Square root of float\n";
        return 0.0;
    }

    double log(double); //declaration inside the namespace
}

//definition outside the namespace
double math_operations::log(double val) {
    std::cout << "Log form math_op\n";
}