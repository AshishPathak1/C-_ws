#pragma once
#include <vector>
#include <string>
namespace mylib {
	class Queue
	{
	public:
		/*Constructs a a queue of specified size*/
		Queue(size_t max_capacity=DEFAULT_CAPACITY);
		/*Insert element (string) at the rear*/
		void push(std::string);
		/*Delete element from the begining on success returs true on failure throws underflow errror*/
		bool pop();
		/*Returns a copy of the first element from the queue*/
		std::string peek();
		/*Returns the number of elements in the queue*/
		size_t size();
		/*Returns the maximum capacity of the queue*/
		size_t max_capacity();
		/*Class that enables us to cycle through the queue*/
		class Iterator;
		/*Returns an Iterator refering to the first element in the queue*/
		Iterator begin();
		/*returns the Iterator pointing to element beyond the last element*/
		Iterator end();
	
	private:
		std::vector<std::string,std::allocator<std::string>>  queue;
	
		static const int DEFAULT_CAPACITY{ 5 };
		/*Points the the element at front*/
		int front;
		/*Points to element at rear*/
		int rear;
		/*Reset the fornt and rear to indicate that the queue is empty*/
		void resetQueue();
		/*Returns true if the queue is empty*/
		bool isEmpty();
		/*Returns True is the Queue is Full otherwise returns false*/
		bool isFull();
		
	};

	class Queue::Iterator {
	public:
		Iterator();
		Iterator(std::string*);
		std::string operator *();
		std::string* operator ++();
		std::string* operator ++(int);
		bool operator !=(Iterator);

	private:
		std::string* iter;
	};
}

