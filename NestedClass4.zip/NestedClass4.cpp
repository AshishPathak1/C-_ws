// NestedClass4.cpp : 

/*
Although nested classes can be considered members of the surrounding class, 
members of nested classes are not members of the surrounding class: 
members of the Surrounding class may not directly call members of nested class
In fact, nested classes are just typenames. 
It is not implied that objects of such classes automatically exist in the surrounding class. 
If a member of the surrounding class should use a (non-static) member of a nested class 
then the surrounding class must define a nested class object, which can thereupon be used by 
the members of the surrounding class to use members of the nested class.
*/
#include <iostream>
#include "Surround.h"
#include "Outer.h"

int main()
{
    
    /*Members of the nested class are not the members of the enclosing surrounding class
    The members of the nested class do not contirbute to the size of the surrounding class object*/
    mylib::Surround sobj;
    std::cout << "Size of Surround class object : " << sizeof(sobj) << " bytes\n";

    mylib::Surround::Inner inner_obj{};
    std::cout << "Size of Surround::Inner class Object : " << sizeof(inner_obj) << " bytes" << std::endl;
    
    mylib::Outer outer_obj{};
    std::cout << "Size of Outer class Object : " << sizeof(outer_obj) << " bytes" << std::endl;
    outer_obj.outer_non_static_function();

    outer_obj.outer_static_function();

    mylib::Outer::outer_static_function();

    mylib::Outer::Inner::showEpoch();

    
}
