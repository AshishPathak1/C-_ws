#include <iostream>
#include "Outer.h"
namespace mylib {


    //Definition of static member outside the class
    size_t Outer::Inner::epoch{ 1970 };

    void Outer::outer_non_static_function()
    {
        d_inner.inner_non_static_function();
        d_inner.showEpoch(); //Not Good Practise
    }

    void Outer::outer_static_function()
    {
        Outer::Inner::showEpoch();

    }

    void Outer::Inner::inner_non_static_function()
    {
        std::cout << "Outer::Inner::inner_non_static_function\n";
    }


    void  Outer::Inner::showEpoch()
    {
        std::cout << "Epoch : " << Outer::Inner::epoch;
    }



}