#pragma once
namespace mylib{

class Outer
{
public:
    void outer_non_static_function();
    static void outer_static_function();
    int data;
private:
    class Inner
    {
    private:
        int data;
        static size_t epoch; //Declaration of static member
    public:
        void inner_non_static_function();
        static void showEpoch();
    };

    // d_inner is a member of Outer class
    Inner d_inner;      // class Inner must be known
};



}
