#pragma once
namespace mylib {

    class Surround {
    private:
        int outer_data;
    public:
        class Inner {
        private:
            int inner_data;
        };
        //Inner in;
    };




}
