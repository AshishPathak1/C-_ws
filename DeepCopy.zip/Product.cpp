#include "Product.h"
#include <iostream>
#include <cstring>
#include <string>
//#define _CRT_SECURE_NO_WARNINGS
myspace::Product::Product(const char* name, float price, int year)
{
	size_t length = std::strlen(name) + 1;
	this->name = new char[length];   //Acquires the resource
	strncpy_s(this->name, length, name, length);
	this->price = price;
	this->year_of_manufacture = year;
}


myspace::Product::~Product()
{
	std::cout << this->name << " is being destroyed\n";
	delete[] this->name;		//Releases the resouce
	this->name = nullptr;
	this->price = 0.0F;
	this->year_of_manufacture = 0;

}

myspace::Product::Product(const Product& other_product)
{
	/*Perform member by member copy for non-pointer fields*/
	this->price = other_product.price;
	this->year_of_manufacture = other_product.year_of_manufacture;

	/*Perform deep copy for pointer member*/
	size_t length = strlen(other_product.name)+1;
	this->name = new char[length];
	strncpy_s(this->name, length, other_product.name, length);

}

int myspace::Product::get_year_of_manufacture() const
{
	return year_of_manufacture;
}

float myspace::Product::get_price() const
{
	return price;
}

std::string myspace::Product::get_name() const
{
	return std::string(this->name);
}

const myspace::Product& myspace::Product::operator=(const Product& other)
{
	/*Perform member by member copy for non-pointer fields*/
	this->price = other.price;
	this->year_of_manufacture = other.year_of_manufacture;

	/*Perform deep copy for pointer member*/
	size_t length = strlen(other.name) + 1;
	if (this->name != nullptr){
		delete[] this->name; //ensures that no-memory leak occurs
	}
	this->name = new char[length];
	strncpy_s(this->name, length, other.name, length);
	return *this;
}

std::ostream& myspace::operator<<(std::ostream& out_stream, const Product& aproduct)
{

	out_stream << "\nName                : " << aproduct.get_name() << "\n"
		<< "Price               : " << aproduct.get_price() << '\n'
		<< "Year of Manufacture : " << aproduct.get_year_of_manufacture() << '\n';
	return out_stream;
}
