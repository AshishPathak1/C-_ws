#include "Product.h"
#include <iostream>
void deep_copy_class_type();
void shallow_copy_primitive_type();
void  store_data(int*, size_t);
void  print_data(int*, size_t);

int main() {
	shallow_copy_primitive_type();
	//deep_copy_class_type();
}

void shallow_copy_primitive_type() {
    try {
        size_t size;
        std::cout << "How many integers do you want to store ? ";
        std::cin >> size;
        int* iptr1 = new int[size];
        store_data(iptr1, size);
        print_data(iptr1, size);

        //Deep copy
        int* iptr2 = new int[size]; //Allocate memory
        for (size_t i{ 0 }; i < size; ++i) { //copy data
            iptr2[i] = iptr1[0];
        }
        print_data(iptr2, size);

        delete[] iptr1;
        iptr1 = nullptr;
        print_data(iptr2, size); //OK
        delete[] iptr2;          //OK
        iptr2 = nullptr;
    }
    catch (std::exception& ref) {
        std::cout << ref.what() << std::endl;
    }
}

void deep_copy_class_type()
{
	myspace::Product product1("Pencil", 30.5F, 2022);
	std::cout << "First Product : " << product1;

	myspace::Product product2(product1);
	std::cout << "Second Product : " << product2;

	myspace::Product product3("Eraser", 50.5F, 2021);
	std::cout << "Third Product : " << product3;

	product1 = product3; // product2.operator=(product3);

	std::cout << "First Product : " << product1;
}


void  store_data(int* array, size_t size) {
    for (size_t i = 0; i < size; ++i) {
        array[i] = i + 10;
    }
}


void  print_data(int* array, size_t size) {
    for (size_t i = 0; i < size; ++i) {
        std::cout << array[i] << ", ";

    }
    std::cout << std::endl;
}
