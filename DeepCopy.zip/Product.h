#pragma once
#include <string>
namespace myspace {
	class Product {
	private:
		char* name;
		float price;
		int year_of_manufacture;
	public:
		Product(const char* name, float price, int year);
		~Product();
		Product(const Product&); //Copy ctor 
		int get_year_of_manufacture() const;
		float get_price()const;
		std::string get_name() const;
		const Product& operator=(const Product&);
	};

	std::ostream& operator <<(std::ostream&, const Product&);
}

