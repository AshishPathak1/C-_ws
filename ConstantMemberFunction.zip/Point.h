#pragma once

namespace my_lib {
	class Point
	{
	public:
		//Ctor
		Point(int _x = 10, int _y = 10);
		
		//Accessor (Getter)
		int getX() const;
		int getY() const;
		void getInfo();
		void getInfo() const;

		//Modifiers (setters)
		void setX(int x);
		void setY(int y);
	
	private:
		/* Coordinates in X-Y plane*/
		int x; 
		int y;
	};
}

