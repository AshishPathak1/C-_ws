// Constant_object_function.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "Point.h"
int main()
{
	/*Non-Constant Object*/
	my_lib::Point p1{ 20,40 };
	std::cout << "P1:\t [ X : " << p1.getX() << ", Y : " << p1.getY() << " ]" << std::endl;

	p1.setX(33);
	p1.setY(44);

	std::cout << "P1:\t [ X : " << p1.getX() << ", Y : " << p1.getY() << " ]" << std::endl;

	/*Constant Object*/
	const my_lib::Point p2{ 2, 4 };
	std::cout << "P2:\t [ X : " << p2.getX() << ", Y : " << p2.getY() << " ]" << std::endl;
	/*p2.setX(33);
	p2.setY(44);*/

	/*Non-constant object can bind with constant and non-constant member function; 
	but give preference to non-constant method*/
	p1.getInfo();
	/*Constant object can bind only with constant member function*/
	p2.getInfo();

}
