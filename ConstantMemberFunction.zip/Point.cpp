#include <iostream>
#include "Point.h"

namespace my_lib {
	/*initializer list*/
	Point::Point(int _x, int _y) : x(_x), y(_y)
	{
	}

	int Point::getX() const{
		return x;
	}

	int Point::getY() const {
		return y;
	}

	void Point::setX(int x) {
		this->x = x;
	}

	void Point::setY(int y)  {
		this->y = y;
	}

	void Point::getInfo()
	{
		std::cout << "Non-constant Object :\t [ X : " << x << ", Y : " << y << " ]" << std::endl;
	}

	void Point::getInfo() const
	{
		std::cout << "Constant Object : \t [ X : " << x << ", Y : " << y << " ]" << std::endl;
	}

}
