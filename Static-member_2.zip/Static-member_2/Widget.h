#pragma once

/*
 * A widget is an element of a graphical user interface (GUI)
 * that displays information or provides a specific way for a
 * user to interact with the operating system or an application.
 *
 * Keep count of Number of widgets created and number of widgets that are alive
 */
#include <string>

namespace graphic {
	class Widget
	{
	public:

		/*Default constructor*/
		Widget(const std::string& name = "Shape");
		/*copy constructor*/
		Widget(const Widget&);
		/*copy assignment*/
		Widget& operator=(const Widget&) = default;
		/*move constructor*/
		Widget(Widget&&) = default;
		/*move assignment*/
		Widget& operator=(Widget&&) = default;
		/*Destructor*/
		virtual ~Widget();
		void switch_to_graphic();
		void switch_to_text();
		std::string getInfo()const;
		
		/*Static methods*/
		static size_t get_total_widget_count();
		static size_t get_live_widget_count();
	private:
		std::string name; //instance data
		/*Keeps count of total widgets created so far*/
		static size_t total_widget_count; //declaration of class data
		/*Keeps a count of number of widget currently present in the memory*/
		static size_t live_widget_count;
	};

}