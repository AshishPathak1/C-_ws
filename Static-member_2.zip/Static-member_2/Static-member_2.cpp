// Static-member_2.cpp : This file contains the 'main' function. Program execution begins and ends there.

/*
 * A widget is an element of a graphical user interface (GUI)
 * that displays information or provides a specific way for a
 * user to interact with the operating system or an application.
 *
 * Keep count of Number of widgets created
 * and number of widgets that are alive
 */

#include <string>
#include <iostream>
#include "Widget.h"
using namespace std::literals;

void draw(graphic::Widget a_widget) {
    std::cout << "Total Number of widgets (draw) : " << graphic::Widget::get_total_widget_count() << std::endl;
    std::cout << "Number of live widgets  (draw) : " << graphic::Widget::get_live_widget_count() << std::endl;

    std::cout << a_widget.getInfo();

    return;
}

void foo() {
    graphic::Widget w{ "Polygon"s };
    std::cout << w.getInfo();
    return;
}

int main()
{
    std::cout << "Total Number of widgets : " << graphic::Widget::get_total_widget_count() << std::endl;
    std::cout << "Number of live widgets  : " << graphic::Widget::get_live_widget_count() << std::endl;
    //Block Scope
    {
        graphic::Widget tri{ "Triangle"s };
        std::cout << tri.getInfo();
        graphic::Widget sqr{ "Square"s };
        std::cout << sqr.getInfo();

    }

    foo();

    graphic::Widget w1{}; //Default parameterized ctor
    std::cout << w1.getInfo();
    graphic::Widget tri{"Triangle"};
    std::cout << tri.getInfo();
    graphic::Widget sqr{ "Square" };
    std::cout << sqr.getInfo();
   
    std::cout << "Number of widgets : " << w1.get_total_widget_count() << std::endl;
    std::cout << "Total Number of widgets : " << graphic::Widget::get_total_widget_count() << std::endl;
    std::cout << "Number of live widgets : " << graphic::Widget::get_live_widget_count() << std::endl;
    draw(sqr);
   
    std::cout << "Total Number of widgets : " << graphic::Widget::get_total_widget_count() << std::endl;
    std::cout << "Number of live widgets  : " << graphic::Widget::get_live_widget_count() << std::endl;
}
