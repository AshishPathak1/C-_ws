#include<iostream>
#include "Widget.h"
namespace graphic {
	
	/*Defining Static members*/
	/*By default initialized to value zero*/
	size_t Widget::total_widget_count{}; //Defined
	size_t Widget::live_widget_count;    //Defined : default initialized to 0


	size_t Widget::get_total_widget_count()
	{
		/*Instance data members cannot be accessed inside static member function*/
		//std::string s =  name;

		/* 'this' : can only be referenced inside non-static member functions */
		//std::string s = this->name;

		/*static function can access only static data*/
		return total_widget_count;
	}


	size_t Widget::get_live_widget_count()
	{
		return live_widget_count;
	}

	/*Defining instance members */

	Widget::Widget(const std::string& name)
	{
		this->name = name;
		total_widget_count++; //Non-static member functions can access static data
		if (++live_widget_count == 1) {
			switch_to_graphic();
		}
	}

	/*copy ctor*/
	Widget::Widget(const Widget& other_obj_ref)
	{
		this->name = other_obj_ref.name;
		++total_widget_count; //Non-static member functions can access static data
		++live_widget_count;

	}


	Widget::~Widget()
	{
		std::cout << "Destroying " << name << std::endl;
		this->name.clear();
		
		if (--live_widget_count == 0) {
			switch_to_text();
		}
	}


	std::string Widget::getInfo()const
	{
		return "The widget is " + name + "\n";
	}


	void Widget::switch_to_graphic() {
		std::cout << "Switching to Graphic Mode" << std::endl;
	}


	void Widget::switch_to_text() {
		std::cout << "Switching to Text Mode" << std::endl;
	}

}