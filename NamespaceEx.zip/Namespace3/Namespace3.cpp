// Namespace3.cpp : 
// The name of a namespace can be re-used within a namespace, 
// but such a name will cause a name clash if used unadorned in the global scope


#include <iostream>

namespace X {
    struct X {
        int data{ 5 };
       //.....
    };

    struct Y {
        int data{ 33 };
        //...
    };
}

int main()
{
    X::X svar1{};
    std::cout << "Accessing Struct X from namespace X : " << svar1.data << std::endl;

    using namespace X; //Brings all names fom X in current scope
    Y yvar{};
    std::cout << "Accessing Struct Y from namespace X : " << yvar.data << std::endl;

 //   X svar2{};  //	"X" is ambiguous	

}

