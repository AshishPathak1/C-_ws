// Namespace4.cpp : Namespaces are open
// There may be more than one namespace declaration of the same name.
// This allows a namespace to be split over several files or even separated within the same file.


#include <iostream>
#include "yourheader.h"

namespace myspace {
    int a{ 10 };
    int foo(int data) {
        return data;
    }
}

//namespace to be split over several files
namespace yourspace {
    double a{ 100.33 };
    int foo(int data) {
        return data;
    }
}

//namespace myspace is split over in the same file
namespace myspace {
    int b{ 20 };
}


namespace alias = myspace;
//A namespace alias cannot be used to add more members to a namespace

//'alias': a symbol with this name already exists and therefore this name cannot be used as a namespace name	

//namespace alias {
//    int c{ 99 };
//}

void foo();

int main()
{
    std::cout << "Accessing variables from namespace myspace: \n";
    std::cout << "myspace::a : " << myspace::a << std::endl;
    std::cout << "myspace::b : " << myspace::b<< std::endl;
    std::cout << "alias::b   : " << alias::b << std::endl;

    std::cout << "Accessing variables from namespace yourspace: \n";
    std::cout << "yourspace::a : " << yourspace::a << std::endl;
    std::cout << "yourspace::b : " << yourspace::b << std::endl;
    std::cout << "yourspace::foo: " << yourspace::foo(33) << std::endl;

    //std::cout << "a : " << a << std::endl; //	'a': undeclared identifier	
    //std::cout << "b : " << b << std::endl; //	'b': undeclared identifier	

    using namespace myspace;
    std::cout << "a : " << a << std::endl; //myspace ::a
    std::cout << "b : " << b << std::endl; //myspace ::b
    std::cout << "foo : " << foo(33) << std::endl;

    using namespace yourspace;
    //std::cout << "a : " << a << std::endl;  //	"a" is ambiguous : could be 'double yourspace::a' or 'int myspace::a'
    //std::cout << "b : " << b << std::endl;  //  "b" is ambiguous : could be 'double yourspace::b' or 'int myspace::b'
    //foo(10); // foo': ambiguous call to overloaded function
               // could be 'int yourspace::foo(int)'    or 'int myspace::foo(int)'
}

void foo()
{
    //std::cout << "a : " << a << std::endl; //	'a': undeclared identifier	
    //std::cout << "b : " << b << std::endl; //	'b': undeclared identifier	
    std::cout << "myspace::a : " << myspace::a << std::endl;
    std::cout << "myspace::b : " << myspace::b << std::endl;
}