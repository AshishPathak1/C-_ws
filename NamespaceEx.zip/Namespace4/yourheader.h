#pragma once
namespace yourspace {
	double b{ 99.99 };
}