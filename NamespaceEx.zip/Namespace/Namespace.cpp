// Namespace.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Nested namespace

#include <iostream>

namespace outerspace {
    int a{ 10 };
    namespace innerspace {
        double a{ 66.77 };
    }
}

int main()
{
    std::cout << "outerspace::a : " << outerspace::a << std::endl;
   
    //'innerspace': is not a class or namespace name	
    //std::cout << "innerspace::a : " << innerspace::a << std::endl;
    std::cout << "innerspace::a : " << outerspace::innerspace::a << std::endl;

    using namespace outerspace;
    std::cout << "outerspace  a: " << a << std::endl;
    std::cout << "innerspace::a: " << innerspace::a << std::endl;

    using namespace outerspace::innerspace;

    //std::cout << a << std::endl;


}


