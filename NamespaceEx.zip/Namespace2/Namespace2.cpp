// Namespace2.cpp : This file contains the 'main' function. Program execution begins and ends there.
// The name of a global namespace must be unique among the global names in a program. 


#include <iostream>

namespace Foo {
    //....
}

//'Foo': has already been defined to be a namespace	
//class Foo {
//
//};


//'Foo': redefinition; previous definition was 'namespace'	
//int Foo(void) {
//
//}


//'Foo': redefinition; previous definition was 'namespace'	
//double Foo{ 10 };

int main()
{
    std::cout << "In main!\n";
    int Foo{ 10 }; //allowed; since it is local 

}
