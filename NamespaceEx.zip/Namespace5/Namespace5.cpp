// Namespace5.cpp : 
// Defining entities outside of their namespaces
// Namespace declarations are context sensitive
#include <iostream>
#include <string>

using namespace std::literals;

namespace myspace {
    int a;

    std::string sayHi(const std::string&); //Declaration

    std::string sayBye(const std::string& name) { //definition
        return "Bye!, "s + name + "\n"s;
    }
}

namespace yourspace {
    namespace innerspace {

        std::string sayHi(const std::string&); //Declaration

        std::string sayBye(const std::string& name) { //definition
            return "Chao Bye!!, "s + name +"\n"s;
        }
    }
}

std::string myspace::sayHi(const std::string& name) {
    return "Mr :"s + name + " from myspace\n"s;
}


//Definition of function outside the namespace declaration
std::string yourspace::innerspace::sayHi(const std::string& name) {
    return "Hello!,"s + name + " from yourspace\n"s;
}

//sayHi lies in the global namespace
std::string sayHi(const std::string& name) {
    return "Hello!,"s + name+" in global namespace\n"s;
}

void foo() {
    // Namespace declarations are context sensitive
    using namespace myspace;
    std::cout <<"mayspace::sayBye : "s << sayBye("SaiRam"s);
}


int main()
{
    std::cout << sayHi("Tejas"s);
    std::cout << myspace::sayHi("Teju"s) << std::endl;
    std::cout << myspace::sayBye("Teja"s) << std::endl;
    std::cout << yourspace::innerspace::sayHi("Dharam"s) << std::endl;
   
   /* using namespace myspace;
    std::cout << sayHi("Tejas");
    'sayHi' : ambiguous call to overloaded function
        could be 'std::string sayHi(std::string)'
        or 'std::string myspace::sayHi(std::string)'*/

   // Namespace declarations are context sensitive
    {
        using namespace myspace;
        std::cout << sayBye("Akash");
    }

    {
        using namespace yourspace::innerspace;
        std::cout << sayBye("Akash");
        std::cout << sayBye("Akash");
    }
  //  std::cout << sayBye("Akash");  //'sayBye': identifier not found
    foo();
}

