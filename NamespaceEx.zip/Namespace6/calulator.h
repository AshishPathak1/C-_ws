#pragma once

long long add(int n1, int n2) {
	return (long long)n1 + n2;
}

long double multiply(int n1, int n2) {
	return (long double)n1 * n2;
}