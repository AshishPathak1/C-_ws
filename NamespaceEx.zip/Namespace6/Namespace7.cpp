// Namespace6.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Sharing data

#include <iostream>
#include <string>
using namespace std::literals;

//Case1
//#include "calulator.h"
//#include "mymath.h"


//Case 2
//#include "new_calc.h"
//#include "new_math.h"


//case 3
#include "mylibrary.h"

int main()
{
    //case1
  /*  {
        std::cout << "Using Calculator!\n";
        int a{ 40 };
        int b{ 3 };
        std::cout << a << " + " << b << " = " << add(a, b) << std::endl;
        std::cout << a << " x " << b << " = " << multiply(a, b) << std::endl;
    }*/

    //case2
    /*{
        int a{ 40 };
        int b{ 3 };
        std::cout << a << " + " << b << " = " << calc::add(a, b) << std::endl;
        std::cout << a << " x " << b << " = " << calc::multiply(a, b) << std::endl;
        std::cout << a << " + " << b << " = " << math_calc::add(a, b) << std::endl;
        std::cout << a << " x " << b << " = " << math_calc::multiply(a, b) << std::endl;
    }*/

    //case3
    {
        std::cout << my_library::welcome("Sayli"s) <<std::endl;
        std::cout << my_library::shared_data << std::endl;
        std::cout << my_library::getdata() << std::endl;
    }
    return 0;
}


