#pragma once
#include <string>
namespace my_library {
	
	/*Takes the name of the participant as a argument and 
	returns a string that welcome the participant*/
	std::string welcome(const std::string& name);
	
	/*Returns the value of the shared data*/
	int getdata();

	/*Declare the shared variable in the header file*/
	extern int shared_data;
}