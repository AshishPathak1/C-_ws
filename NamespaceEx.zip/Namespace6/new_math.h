#pragma once

namespace math_calc {
	int add(int n1, int n2) {
		return n1 + n2;
	}

	int multiply(int n1, int n2) {
		return n1 * n2;
	}
}