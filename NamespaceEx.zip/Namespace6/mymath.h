#pragma once

int add(int n1, int n2) {
	return n1 + n2;
}

long int multiply(int n1, int n2) {
	return n1 * n2;
}