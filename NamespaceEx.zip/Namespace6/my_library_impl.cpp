#pragma once
#include <string>
#include "mylibrary.h"

using namespace std::literals;

namespace my_library{
	/*define the shared variable in the implementation file*/
	int shared_data{ 99 };

	/*Definition of the functions*/
	std::string welcome(const std::string& name) {
		return "Welcome "s + name;
	}

	int getdata() {
		return shared_data;
	}
}