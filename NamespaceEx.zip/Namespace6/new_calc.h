#pragma once
//implementation is exposed
//conflict of names is avoided
namespace calc {
	/*....*/
	long long add(int n1, int n2) {
		return (long long)n1 + n2;
	}
	/*...*/
	long double multiply(int n1, int n2) {
		return (long double)n1 * n2;
	}
}