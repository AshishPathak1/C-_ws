// Namespace7.cpp : 
// When an inline namespace is defined, a using directive is implicitly inserted into its enclosing namespace. 


#include <iostream>

namespace foo {
    void foo_func() {
        std::cout << "Inside foo::foo_func\n";
    }
}

inline namespace bar {
    void bar_func() {
        std::cout << "Inside bar::bar_func\n";
    }
}


int main()
{
    {
       // foo_func();
        /*When an inline namespace is defined, a using directive is implicitly 
        inserted into its enclosing namespace.
        using namespace bar;
        */
        bar_func();
    }

    {
        foo::foo_func();
        bar::bar_func();
        bar_func();
    }

    {
        using namespace foo;
        foo_func();
      //  using namespace bar;
        bar_func();
    }
}
