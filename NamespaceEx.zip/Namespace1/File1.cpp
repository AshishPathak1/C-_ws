// Namespace1.cpp :
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <numbers>

int deg = 180;
using std::cout;
using std::endl;

extern int gvar2;
extern void printit();


namespace mylib {
	double cos(double deg)
	{
		double rad = deg * (std::numbers::pi / 180);
		double result = std::cos(rad);
		return result;
	}
}

int main()
{
//	cout << "In ,File1::main gvar1 : " << gvar1 << endl;
	cout << "In ,File1::main gvar2 : " << gvar2 << endl;
	double cin = 180;
	double x = mylib::cos(cin);
	cout << "Cos of (using lib) " << cin << " = " << x << endl;
	cout << "Please enter the degree : ";
	std::cin >> deg;
	x = cos(deg);
	std::cout << "Cos of (my version)" << deg << " = " << x << std::endl;

	std::cout << "Cos of (my version)" << deg << " = " << x << std::endl;
	printit();
	//doit(); //unresolved external symbol "void doit(void)" 

	return 0;
}

