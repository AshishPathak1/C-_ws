#pragma once
#include <iostream>
#include <string>
using namespace std::literals;


namespace my_library {

	namespace v1 {
		void doit() {
			std::cout << "Doing it in Traditional way!\n"s;
		}
	}

	namespace v2 {
		void doit() {
			std::cout << "Doing it in New way!\n"s;
		}
	}

	inline namespace v3 {
		void doit() {
			std::cout << "Doing it in Latest way!\n"s;
		}
	}
	
}