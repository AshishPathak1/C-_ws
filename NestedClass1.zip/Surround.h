#pragma once

namespace mylib {

	class FirstWithin { //class declared at namespace level
	public:
		FirstWithin();
	};

	class Surround
	{
	public:
		void surrounding_function();

		class FirstWithin //class is defiend within class Surround
		{
			int d_variable;

		public:
			FirstWithin();
			int var() const;
		};

	private:
		class SecondWithin
		{
			int d_variable;

		public:
			SecondWithin();
			int var() const;
		};
	};

}

