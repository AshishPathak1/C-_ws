// NestedClass.cpp : 
/*
A class can be nested in every part of the surrounding class: in the public, protected or private section.
If a class is nested in the public section of a class, it is visible outside the surrounding class.
If it is nested in the protected section it is visible in subclasses, derived from the surrounding class,
if it is nested in the private section, it is only visible for the members of the surrounding class.

*/

#include <iostream>
#include "Surround.h"

int main() {
	//FirstWithin fobj;			//Error
	mylib::FirstWithin fobj1;	//Accessing the class FirstWithin present at the namespace level
	/*If a class is nested in the public section of a class, it is visible outside the surrounding class.*/
	mylib::Surround::FirstWithin fobj2; //OK

	/*if it is nested in the private section, it is only visible for the members of the surrounding class.*/
	//mylib::Surround::SecondWithin sobj;
}