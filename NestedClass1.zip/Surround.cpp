#include <iostream>
#include "Surround.h"

namespace mylib {

	FirstWithin::FirstWithin() {
		std::cout << "First Class at namespace level\n";
	}

	void Surround::surrounding_function() {
		//if it is nested in the private section, it is only visible for the members of the surrounding class
		Surround::SecondWithin sobj;
		Surround::FirstWithin  fobj;
	}


	Surround::FirstWithin::FirstWithin() :d_variable(44)
	{
		std::cout << "First Class within Surround\n";
	}

	inline int Surround::FirstWithin::var() const
	{
		return d_variable;
	}


	Surround::SecondWithin::SecondWithin() :d_variable(99)
	{
	}

	inline int Surround::SecondWithin::var() const
	{
		return d_variable;
	}

}