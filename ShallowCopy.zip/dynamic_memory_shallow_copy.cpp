// Shallow Copy and Deep Copy

#include <iostream>
#include "Product.h"

void shallow_copy();
void  store_data(int*, size_t);
void  print_data(int*, size_t);
void shallow_copy_with_class_object();

int main()
{
    //shallow_copy();
    shallow_copy_with_class_object(); // need for overloading operator = & copy constructor
    
}

void shallow_copy() {
    try {
        size_t size;
        std::cout << "How many integers do you want to store ? ";
        std::cin >> size;
        int* iptr1 = new int[size];
        store_data(iptr1, size);
        print_data(iptr1, size);

        int* iptr2 = iptr1; //Shallow cpoy
        print_data(iptr2, size);

        delete[] iptr1;
        iptr1 = nullptr;
        print_data(iptr2, size); //Dangling
        delete[] iptr2;          //Exception : Failure
        iptr2 = nullptr;
    }
    catch (std::exception& ref) {
        std::cout << ref.what() << std::endl;
    }
}

void  store_data(int* array, size_t size) {
    for (size_t i = 0; i < size; ++i) {
        array[i] = static_cast<int>(i + 10);
    }
}


void  print_data(int* array, size_t size) {
    for (size_t i = 0; i < size; ++i) {
        std::cout << array[i] << ", ";

    }
    std::cout << std::endl;
}

void shallow_copy_with_class_object()
{
    ////Case-1 : No worries
    //{
    //    myspace::Product p("Pen", 56.5F, 2021); //Stack
    //    std::cout << p;
    //}
    ////case - 2
    //{
    //    myspace::Product* product_ptr{ nullptr };  //stack
    //    product_ptr = new myspace::Product("Maker Pen", 200.0F, 2021); //Object is on heap
    //    std::cout << *product_ptr;
    //    delete product_ptr;         // Releasing memory of object residing on heap
    //    product_ptr = nullptr;
    //}


    ////Case 3 :Failure
    //{
    //    myspace::Product* product_ptr = nullptr;  //stack
    //    product_ptr = new myspace::Product("Compass", 1200.0F, 2021); //Object is on heap
    //    std::cout << *product_ptr;

    //    myspace::Product* another_product = product_ptr; 
    //    std::cout << *another_product;

    //    delete product_ptr;         // Releasing memory of object residing on heap
    //    product_ptr = nullptr;
    //   
    //    delete another_product;    // Releasing memory of object residing on heap
    //    product_ptr = nullptr;

    //}

    // case - 4 : Failure :Ownership issue due to sharing
    {
        myspace::Product p1("Ink Bottle", 500.0F, 2022); //Object is on Stack
        std::cout << p1;

        myspace::Product p2(p1);   // copy constructor is invoked
        std::cout << p2;
       
    }
}