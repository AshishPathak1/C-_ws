#include "Product.h"
#include <iostream>
#include <cstring>
#include <string>
//#define _CRT_SECURE_NO_WARNINGS
myspace::Product::Product(const char* name, float price, int year)
{
	size_t length = std::strlen(name) + 1;
	this->name = new char[length];   //Acquires the resource
	strncpy_s(this->name, length, name, length );
	this->price = price;
	this->year_of_manufacture = year;
}


myspace::Product::~Product()
{
	std::cout << this->name << " is being destroyed\n";
	delete[] this->name;		//Releases the resouce
	this->name = nullptr;
	this->price = 0.0F;
	this->year_of_manufacture = 0;

}

int myspace::Product::get_year_of_manufacture() const
{
	return year_of_manufacture;
}

float myspace::Product::get_price() const
{
	return price;
}

const std::string myspace::Product::get_name() const
{
	return std::string(this->name);
}

std::ostream& myspace::operator<<(std::ostream& out_stream, const Product& aproduct)
{

	out_stream << "\nName                : " << aproduct.get_name() << "\n"
		<< "Price               : " << aproduct.get_price() << '\n'
		<< "Year of Manufacture : " << aproduct.get_year_of_manufacture() << '\n';
	return out_stream;
}
