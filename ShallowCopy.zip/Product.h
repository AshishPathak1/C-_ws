#pragma once
#include <string>
namespace myspace {
	class Product{
	private:
		char* name;
		float price;
		int year_of_manufacture;
	public:
		Product(const char* name, float price, int year);
		~Product();
		int get_year_of_manufacture() const;
		float get_price()const;
		const std::string get_name() const;
	};

	std::ostream& operator <<(std::ostream&, const Product&);
	//cout << p; => cout.operator<<(p)
	//			 => operator<<(cout,p)
}

