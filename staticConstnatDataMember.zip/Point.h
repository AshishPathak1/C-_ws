#pragma once
namespace mylib {
	//constant Class data
	class Point // Point in X-Y plane
	{
	private:
		int x_cord;
		int y_cord;
	public:
		Point(int x, int y);
		Point() = delete;
		/* Returns the X-coordinate of the point*/
		int getX() const;
		/* Returns the Y-coordinate of the point*/
		int getY() const;

		//declaration of Static const data members
		static const int x_origin{ 10 };
		const static int y_origin{ 10 };
	};
	

}

