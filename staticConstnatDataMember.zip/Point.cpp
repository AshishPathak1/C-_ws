#include "Point.h"
namespace mylib {
	Point::Point(int x, int y):x_cord(x),y_cord(y) {}

	int Point::getX() const {
		return x_cord;
	}


	int Point::getY() const {
		return y_cord;
	}

	//Definition of Static const data members
	const int Point::x_origin;
	const int Point::y_origin;
}