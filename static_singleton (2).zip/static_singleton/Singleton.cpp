#include "Singleton.h"

namespace old_lib {
    Singleton::Singleton()
    {
        name = "default_name";
        for (size_t i = 1; i <= 100000U; ++i) {
            data.push_back(i);
        }
    }

    std::string Singleton::get_name()
    {
        return name;
    }

    size_t Singleton::get_data_size()
    {
        return data.size();
    }
}


namespace new_lib {

    Singleton& new_lib::Singleton::getInstance()
    {
        static Singleton instance;
        return instance; //return reference of the static object which is created only once
    }

    
    
    Singleton::Singleton()
    {
        name = "default_name";
        for (size_t i = 1; i <= 100000U; ++i) {
            data.push_back(i);
        }
    }

    std::string Singleton::get_name() const
    {
        return name;
    }

    size_t Singleton::get_data_size() const
    {
        return data.size();
    }

}