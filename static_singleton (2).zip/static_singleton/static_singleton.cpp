// static_singleton.cpp : 

/*
In software engineering, the singleton pattern is a software design pattern that
restricts the instantiation of a class to one "single" instance.
This is useful when exactly one object is needed to coordinate actions across the system.
*/

#include <iostream>
#include <chrono>
#include "Singleton.h"

void increment() {
	static int counter{ 0 };
	counter++;
	std::cout << "counter : " << counter <<std::endl;
}

int main()
{
	/*{

		auto one_tousand = 500;
		auto start = std::chrono::system_clock::now();
		for (int i = 1; i <= one_tousand; ++i) {
			old_lib::Singleton s1{};
			old_lib::Singleton s2{};

			std::cout << "S1 : " << "\n\tName :" << s1.get_name()\
				<< "\n\tData Size :" << std::dec << s1.get_data_size()
				<< "\n\tAddress : " << std::hex << &s1 << std::endl;
			std::cout << "S2 : " << "\n\tName :" << s2.get_name()\
				<< "\n\tData Size :" << s2.get_data_size()
				<< "\n\tAddress : " << std::hex << &s2 << std::endl;
		}
		auto total_time = std::chrono::system_clock::now() - start;
		auto time_elapsed = std::chrono::duration<double>(total_time).count();
		std::cout << "Total Time required : " << time_elapsed << std::endl;

	}*/

	//understand the static local variable lifetime
	/*{
		increment();
		increment();
		increment();
		increment();
	}*/
	{
		auto one_tousand = 500;
		auto start = std::chrono::system_clock::now();
		for (int i = 1; i <= one_tousand; ++i) {
			//	new_lib::Singleton s1{}; //error since the ctor is private

			auto& s1 = new_lib::Singleton::getInstance();
			//std::cout << "\n\tS1 Address : " << std::hex << &s1 << std::endl;
			//new_lib::Singleton& s2 = new_lib::Singleton::getInstance();
			//std::cout << "\n\tS2 Address : " << std::hex << &s2 << std::endl;
			//new_lib::Singleton s3(s1);
			//new_lib::Singleton s3 = s1;
			//std::cout << "\n\tS3 Address : " << std::hex << &s3 << std::endl;
			std::cout << "S1 : " << "\n\tName :" << s1.get_name()\
				<< "\n\tData Size :" << s1.get_data_size()
				<< "\n\tAddress : " << std::hex << &s1 << std::endl;
		}
		auto total_time = std::chrono::system_clock::now() - start;
		auto time_elapsed = std::chrono::duration<double>(total_time).count();
		std::cout << "Total Time required : " << time_elapsed << std::endl;
	
	}
}
