#pragma once
#include<string>
#include <vector>

namespace old_lib {
	class Singleton
	{
	private:
		std::string name;
		std::vector<int> data;
	public:
		Singleton();
		std::string get_name();
		size_t get_data_size();
	};

}

namespace new_lib {
	class Singleton
	{
	private:
		std::string name;
		std::vector<int> data;
		Singleton(); //private constructor
	public:
		static Singleton& getInstance();
		std::string get_name() const;
		size_t get_data_size() const;

		/*Restrict the compiler from supplying the copy ctor, move ctor 
		and overloaded assignment operator function */
		Singleton(const Singleton&) = delete;
		Singleton& operator=(const Singleton&)=delete;
		Singleton(Singleton&&) = delete;
		Singleton& operator=(Singleton&&) = delete;

	};

}