#include "Surround.h"
#include <utility>
namespace my_lib {

	Surround::FirstWithin::FirstWithin() :d_variable(44)
	{
	}

	int Surround::FirstWithin::get_var() const
	{
		return d_variable;
	}


	Surround::SecondWithin::SecondWithin() :d_variable(99)
	{
	}

	int Surround::SecondWithin::var() const
	{
		return d_variable;
	}

	
	void Surround::surrounding_function() {
		//public member functions of the public nested class are accessible to 
		// the member functions of the surrounding class
		Surround::FirstWithin  fobj1;
		//if it is nested in the private section, it is only visible for the members of the surrounding class
		Surround::SecondWithin sobj1;
	
	}

}