#pragma once
/*
In order to save space, nested class interfaces are usually declared inside their surrounding class. 
Often this can be avoided, which is desirable as it more clearly separates the outer class's interface 
and the nested class's interface. Likewise, in-class member implementations should be avoided.
*/
namespace my_lib {
	
	class Surround
	{
	public:
		
		class FirstWithin ;		//Forward declaration
		void surrounding_function();
	private:
		class SecondWithin;		//Forward declaration

	}; //end of Surround class declaration



	class Surround::FirstWithin
	{
	private:
		int d_variable;

	public:
		FirstWithin();
		int get_var() const;
	};



	class Surround::SecondWithin
	{
	private:
		int d_variable;

	public:
		SecondWithin();
		int var() const;
	};

}