// NestedClass2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <vector>
#include <list>
#include <string>
#include <algorithm>
#include <string_view>
#include "Surround.h"
void demo_of_iterator();
int main()
{

	std::cout  << std::endl;
	my_lib::Surround::FirstWithin fobj1{};
	std::cout << "Firstwithin::var : " << fobj1.get_var() << std::endl;

	//SecondWithin is private and thus not accessible
	//my_lib::Surround::SecondWithin sobj1{};

	my_lib::Surround surround_obj{};
	surround_obj.surrounding_function();

	demo_of_iterator();
		
}

void demo_of_iterator() {
	std::vector<int> vector_odd{ 1,3,5,7,9 };
	std::vector<int>::iterator iv_itor;

	std::cout << "Odd Numbers are as follows :\n";
	for (iv_itor = vector_odd.begin(); iv_itor != vector_odd.end(); ++iv_itor) {
		std::cout << *iv_itor << ", ";
	}
	std::cout << std::endl;

	using namespace std::literals;
	std::list<std::string> friends{"Raju"s, "Mandar"s, "Priya"s, "Rani"s};

	std::cout << "Friend names are as follows\n";
	std::list<std::string>::iterator list_itor;
	for (list_itor = friends.begin(); list_itor != friends.end(); ++list_itor) {
		std::cout << *list_itor << ", ";
	}
	std::cout << std::endl;
	std::for_each(friends.begin(), friends.end(), [](std::string_view s) {std::cout << s << ", "; });
	            //range from begin to end         

}
