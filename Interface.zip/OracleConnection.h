#pragma once
#include <iostream>
#include "Connection.h"
namespace mylib {

    class OracleConnection : public I_Connection
    {

    public:
        void connect(void) override;

        void disconnect(void) override;

        std::string getConnectionInfo(void) override;
       

     };

}