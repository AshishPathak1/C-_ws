#include "MongoConnection.h"
#include "Connection.h"
namespace mylib {
	void MongoConnection::connect(void) {
		std::cout << "Connecting to Mongo Database using Connection String\n";

	}

	void MongoConnection::disconnect(void) {
		std::cout << "Disconnecting to Mongo Database\n";

	}

	std::string MongoConnection::getConnectionInfo(void) {
		return "Using Mongo DataBase\n";

	}
}