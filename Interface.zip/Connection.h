#pragma once
#include <string>
namespace mylib {

	class I_Connection
	{
	public:
		I_Connection() = default;
		virtual ~I_Connection() = default;
		
		/*Mandates the subtypes to implement the Pure Virtual Functions*/
		virtual void connect(void) = 0;
		virtual void disconnect(void) = 0;
		virtual std::string getConnectionInfo(void) = 0;
	};
}

