#pragma once
#include "Connection.h"
#include "Connection.h"
#include "MySQLConnection.h"
#include "OracleConnection.h"
#include "MongoConnection.h"
#include <iostream>
namespace mylib {
	mylib::I_Connection* getConnection();
	
}

