#include "OracleConnection.h"
#include <iostream>
#include <string>

void mylib::OracleConnection::connect(void)  {
    std::cout << "Connecting to Oracle Database using Connection String\n";

}


void mylib::OracleConnection::disconnect(void)  {
    std::cout << "Disconnecting to Oracle Database\n";

}


std::string mylib::OracleConnection::getConnectionInfo(void)  {
    return "Using Oracle DataBase\n";

}