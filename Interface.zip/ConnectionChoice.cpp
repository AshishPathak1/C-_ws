#pragma once
#include "Connection.h"
#include "MongoConnection.h"
#include "MySQLConnection.h"
#include "OracleConnection.h"

#include <iostream>
namespace mylib {


	mylib::I_Connection* getConnection()
	{
		std::cout << "Enter 1 for Oracle or 2 for MySQL or 3 for Mongo: ";
		int choice;
		std::cin >> choice;
		if (choice == 1) {
			return new mylib::OracleConnection();
		}
		else if (choice == 2) {
			return new mylib::MySQLConnection();
		}

		else if (choice == 3) {
			return new mylib::MongoConnection();
		}

		return nullptr;
	}
}

