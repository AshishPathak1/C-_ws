#include "MySQLConnection.h"
#include <iostream>
#include <string>

namespace mylib {
    void MySQLConnection::connect(void) {
        std::cout << "Connecting to MySQL Database using Connection String\n";

    }


    void  MySQLConnection::disconnect(void)  {
        std::cout << "Disconnecting to MySQL Database\n";

    }


    std::string  MySQLConnection::getConnectionInfo(void) {
        return "Using MySQL DataBase\n";

    }
}