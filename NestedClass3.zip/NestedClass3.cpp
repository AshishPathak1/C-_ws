// NestedClass3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "Outer.h"
int main()
{
    mylib::Outer outer_obj;
    outer_obj.foo();
}
