#include "Outer.h"

namespace mylib {

	Outer::Outer() {

	}


	void Outer::foo() {
		Outer::Inner1 i1{};
		Outer::Inner2 i2{};
	}

	class Outer::Inner2;


	Outer::Inner1::Inner1() {
		pi2 = new Inner2();

	}

	Outer::Inner2::Inner2() {
		data = 55;
	}
}