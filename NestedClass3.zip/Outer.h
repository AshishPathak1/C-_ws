#pragma once

namespace mylib {
    class Outer
    {
    public:
        Outer();
        void foo();
    private:
        class Inner2;       // forward declaration

        class Inner1
        {
        public:
            Inner1();
        private:
            Inner2* pi2;    // points to Inner2 objects
            //Inner2 i2;    //Error
        };

        class Inner2
        {
        public:
            Inner2();
        private:
            int data;    // points to Inner1 objects
        };


    };
}
